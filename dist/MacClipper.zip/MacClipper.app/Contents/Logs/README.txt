MacClipper writes runtime logs into this folder.

Main log:
capture.log

Legacy log fallback:
replay-buffer.log

macOS crash reports are still written separately to:
~/Library/Logs/DiagnosticReports/
